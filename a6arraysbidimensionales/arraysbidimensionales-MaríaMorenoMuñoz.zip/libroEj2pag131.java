package arraysbidimensionales;

import java.util.*;

/*
 * 2.Escribe un programa que pida 20 n�meros enteros. Estos n�meros se deben
introducir en un array de 4 filas por 5 columnas. El programa mostrar� las
sumas parciales de filas y columnas igual que si de una hoja de c�lculo se
tratara. La suma total debe aparecer en la esquina inferior derecha.

 * @author Mar�a Moreno Mu�oz
 * @since 24/11/2019
 * */

public class libroEj2pag131 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int[][] numeros = new int[4][5];

		int fila, columna;
		double sumaTotal = 0;
			
		for (fila = 0; fila < 4; fila++) {
			for (columna = 0; columna < 5; columna++) {
				System.out.println("indique el numero que se guardara en la posici�n" + fila + "," + columna);
				numeros[fila][columna] = sc.nextInt();
				sumaTotal += numeros[fila][columna];
				
			}
		}
		columna=0;
		int i=0;
		System.out.println("      |columna0| columna1| columna2| columna3| columna4|  total");
		for ( fila = 0; fila < 5; fila++) {
			
			if (i < 4) {
				System.out.print("\n Fila" + i + " |  ");
				i++;
				double sumaFila = 0;
				
				for ( columna = 0; columna < 5; columna++) {
					System.out.print( numeros[fila][columna] + "    |    " );
					sumaFila+= numeros[fila][columna] ;
				}
				System.out.print(sumaFila);
				
			} else {
				System.out.print("\n total | " );
				for (int c = 0; c < 5; c++) {
					double sumaColumna = 0;
					
					for (int f = 0; f < 4; f++) {
						sumaColumna += numeros[f][c];
					}
					System.out.print(sumaColumna + "  |  ");

				}
				System.out.print(sumaTotal);

			}
			
		}
		
	}
// 				sumaColumna+=numeros[fila][columna] ; no se como hacer la suma de columnas;

}
